<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>RepairsLab Web Page - Documentation</title>

<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="generator" content="HAPedit 3.0">
<style type="text/css">
@import url("css/layout.css");
a#viewcss{color: #00f;font-weight: bold}
</style>
</head>
<body>
<div id="container">
<div id="header">
<h1>RepairsLab&nbsp;</h1>
</div>
<div id="navigation">
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="https://sourceforge.net/projects/repairslab/">SourceForge</a></li>
<li><a href="licence.php">Licence</a></li>
<li><a href="https://sourceforge.net/project/showfiles.php?group_id=241576">Download</a></li>
<li><a href="index.php#">F.A.C.</a></li>
<li><a id="activelink" href="#">Documentation</a></li>
</ul>
</div>
<div id="extra">
<div class="newsbox"><a href="http://sourceforge.net"><img src="http://sflogo.sourceforge.net/sflogo.php?group_id=241576&amp;type=3" alt="SourceForge.net Logo" border="0" height="37" width="125"></a></div>
<div class="newsbox"><br>
</div>
</div>
<div id="content">
<h2>User Guide</h2>
<br>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tbody>
<tr>
<td>English</td>
<td>RepairsLabUserGuide-en</td>
<td><a target="_blank" href="documents/RepairsLabUserGuide-en_html/RepairsLabUserGuide-en.html">html</a></td>
<td><a target="_blank" href="documents/RepairsLabUserGuide-en.pdf">pdf</a></td>
</tr>
<tr>
<td>Italian</td>
<td>RepairsLabUserManual-it.pdf</td>
<td><a target="_blank" href="documents/RepairsLabUserManual-it_html/RepairsLabUserManual-it.html">html</a></td>
<td><a target="_blank" href="documents/RepairsLabUserManual-it.pdf">pdf</a></td>
</tr>
</tbody>
</table>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div>
<div id="footer">
<div class="xright">� 2008 </div>
</div>
</div>
</body></html>